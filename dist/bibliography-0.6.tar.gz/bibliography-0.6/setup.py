#from py2exe.build_exe import py2exe
from distutils.core import setup
setup(name='bibliography', version='0.6', py_modules=['bibl'])#console=[{"script": "bibl.py"}] )
